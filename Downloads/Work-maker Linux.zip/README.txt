===== Portugu�s ========
Esse programa foi criado no intuito de ajudar as pessoas a fazerem seus trabalhos de escola
e ajudar em pesquisas rapidas.
Este programa n�o tem inten��o de cobrar dinheiro, e n�o tem fins lucrativos, se voc� ver 
algu�m comercializando este produto, por favor denuncie!
====== English =========
This program was created to help people do their homework.
and help with quick searches.
This program is not intended to charge money, and is not for profit if you see
Anyone marketing this product, please report it!

Antenciosamente, Luiz Guilherme Costa da Silva
==============================================
Sincerely, Luiz Guilherme Costa da Silva
========================================